                         ___ ___ ___ ___ ___ ___ ___ ___ ___  
                        |___|___|___|___|___|___|___|___|___| 
                        | |Type a password to Decrypt the | | 
                        | |File.                          | | 
                        | |Note:Password will be invisible| | 
			|_|Warning:Wrong Password will    |_| 
			|_|Destroy the File.              |_|
                        |_|_ ___ ___ ___ ___ ___ ___ ___ _|_| 
                        |___|___|___|___|___|___|___|___|___| 